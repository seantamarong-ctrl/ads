export default function Meta({title, description}) {
  return (
    <>
      <title>{title || 'tinylinks.net — Shorten. Brand. Track.'}</title>
      <meta name="description" content={description || 'tinylinks.net: fast, secure URL shortening with branded domains, QR codes, analytics, and link-in-bio pages.'} />
      <link rel="canonical" href="https://tinylinks.net/" />
      <meta property="og:title" content={title || 'tinylinks.net — Shorten. Brand. Track.'} />
      <meta property="og:description" content={description || 'tinylinks.net: fast, secure URL shortening with branded domains, QR codes, analytics, and link-in-bio pages.'} />
    </>
  )
}
