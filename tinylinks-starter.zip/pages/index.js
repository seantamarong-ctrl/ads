import Meta from '../components/Meta'
import {useState} from 'react'

export default function Home(){
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)

  async function handleShorten(e){
    e.preventDefault()
    setLoading(true)
    const target = e.target.target_url.value
    const alias = e.target.alias.value || undefined
    // call our placeholder API
    const res = await fetch('/api/links', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({target, alias})
    })
    const data = await res.json()
    setResult(data)
    setLoading(false)
  }

  return (
    <div className="container">
      <Meta />
      <header>
        <img src="/logo.svg" alt="tinylinks logo" height="48" />
        <nav style={{marginLeft:'auto'}}> <a href="/features">Features</a> &nbsp; | &nbsp; <a href="/pricing">Pricing</a></nav>
      </header>

      <main>
        <section className="hero">
          <div>
            <h1>Short links. Big results.</h1>
            <p>Create custom, secure, trackable short links — with QR codes, branded domains and analytics.</p>
          </div>

          <aside>
            <form className="shorten-box" onSubmit={handleShorten}>
              <label>Long URL</label>
              <input name="target_url" type="url" placeholder="https://example.com/very/long/url" required />
              <label>Custom alias (optional)</label>
              <input name="alias" type="text" placeholder="e.g. sale-summer" />
              <button type="submit">{loading ? 'Creating…' : 'Shorten'}</button>
            </form>

            {result && (
              <div style={{marginTop:12}}>
                <p>Short URL:</p>
                <a href={result.shortUrl}>{result.shortUrl}</a>
                <p>QR: <img src={result.qr} alt="qr" style={{display:'block',marginTop:8,maxWidth:'100%'}}/></p>
              </div>
            )}
          </aside>
        </section>
      </main>

      <footer>
        <small>tinylinks.net — starter kit. Privacy & Terms coming soon.</small>
      </footer>
    </div>
  )
}
