import Meta from '../components/Meta'
export default function Pricing(){
  return (
    <div className="container">
      <Meta title="Pricing - tinylinks.net" description="Pricing plans for individuals, teams and enterprises." />
      <header><img src="/logo.svg" alt="logo" height="48" /></header>
      <main>
        <h1>Pricing</h1>
        <p>Free tier + Pro + Teams + Enterprise. (This is a starter.)</p>
      </main>
    </div>
  )
}
