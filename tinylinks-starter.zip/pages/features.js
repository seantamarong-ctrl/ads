import Meta from '../components/Meta'
export default function Features(){
  return (
    <div className="container">
      <Meta title="Features - tinylinks.net" description="Features: URL shortener, QR codes, link-in-bio, branded links, analytics, and more." />
      <header><img src="/logo.svg" alt="logo" height="48" /></header>
      <main>
        <h1>Features</h1>
        <ul>
          <li>Custom & branded links</li>
          <li>Password-protected links (coming soon)</li>
          <li>Expiry dates & scheduling</li>
          <li>QR codes & 2D barcodes</li>
          <li>Link-in-bio pages</li>
          <li>Analytics & UTM tracking</li>
        </ul>
      </main>
    </div>
  )
}
