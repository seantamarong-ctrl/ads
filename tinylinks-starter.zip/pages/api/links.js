// Placeholder API route for creating short links (demo only)
export default function handler(req, res){
  if (req.method !== 'POST') {
    res.status(405).json({error:'Method not allowed'})
    return
  }
  const { target, alias } = req.body || {}
  if (!target) {
    res.status(400).json({error:'target url required'})
    return
  }
  // This demo returns a fake alias and a data URL QR placeholder.
  const usedAlias = alias || Math.random().toString(36).substring(2,9)
  const shortUrl = `https://tinylinks.net/${usedAlias}`
  // Simple SVG QR placeholder (replace with real QR generation server-side)
  const qr = `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'><rect width='100%' height='100%' fill='%23f3f4f6'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-size='10' fill='%230f172a'>QR+${usedAlias}</text></svg>`
  res.status(200).json({id:usedAlias, alias:usedAlias, shortUrl, qr})
}
