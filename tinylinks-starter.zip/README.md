# tinylinks-starter
Minimal Next.js starter for tinylinks.net (SSR-ready).

## Getting started
1. unzip or clone this project
2. install dependencies: `npm install` or `yarn`
3. run dev: `npm run dev`

This starter includes:
- Next.js pages and basic SEO-ready components
- A placeholder API route for creating short links
- An animated SVG logo in /public
